"""dlmd_e2/resample.py

DLMD exercise 2, Deep Learning for Medical Diagnostics, RWTH Aachen University, Winter Semester 2026/27.
"""

import numpy as np

N_BOOT = 1000   # bootstrap samples, the same for every team
BOOT_SEED = 0


class Bootstrap:
    """Bootstrap confidence intervals with the settings of the course.

    Without groups, every bootstrap sample draws single rows. With groups, for example the patient ids, every sample draws whole groups, so all images of a drawn patient enter the sample together.
    """

    def __init__(self, n_boot=N_BOOT, seed=BOOT_SEED):
        self.n_boot = int(n_boot)
        self.seed = int(seed)

    def run(self, statistic, n, groups=None):
        """Recompute a statistic on n_boot bootstrap samples.

        Args:
            statistic: function that takes an array of row indices and returns a float.
            n: number of rows in the evaluation set.
            groups: optional (n,) array with the group of every row.

        Returns:
            (mean, sd, low, high): the mean and the standard deviation of the bootstrap values, and their 2.5th and 97.5th percentiles.
        """
        rng = np.random.default_rng(self.seed)
        values = []
        if groups is None:
            for _ in range(self.n_boot):
                values.append(statistic(rng.integers(0, n, size=n)))
        else:
            groups = np.asarray(groups)
            unique = np.unique(groups)
            rows_of = {g: np.where(groups == g)[0] for g in unique}
            for _ in range(self.n_boot):
                drawn = rng.integers(0, len(unique), size=len(unique))
                idx = np.concatenate([rows_of[unique[k]] for k in drawn])
                values.append(statistic(idx))
        v = np.asarray(values, dtype=float)
        v = v[~np.isnan(v)]
        if len(v) == 0:
            return float("nan"), float("nan"), float("nan"), float("nan")
        return (float(v.mean()), float(v.std(ddof=1)),
                float(np.percentile(v, 2.5)), float(np.percentile(v, 97.5)))


def format_ci(mean, sd, low, high, percent=False):
    """Format a bootstrap result as mean ± SD with its 95% confidence interval.

    Values are printed with 3 decimals, or in percent with 1 decimal when percent is True.
    """
    if percent:
        return "{:.1f}% ± {:.1f} (95% CI {:.1f} to {:.1f})".format(
            100 * mean, 100 * sd, 100 * low, 100 * high)
    return "{:.3f} ± {:.3f} (95% CI {:.3f} to {:.3f})".format(mean, sd, low, high)
