"""dlmd_e2/encoder.py

DLMD exercise 2, Deep Learning for Medical Diagnostics, RWTH Aachen University, Winter Semester 2026/27.
"""

from pathlib import Path

import numpy as np
import onnxruntime as ort


class Encoder:
    """The frozen image encoder: ResNet-18 with its ImageNet weights, cut after the last convolutional block.

    It maps a grayscale image of 224 by 224 pixels to 512 feature maps of 7 by 7. The feature vector of an image contains the means of the 512 maps, as in features.npz.
    """

    def __init__(self, path="data/encoder/resnet18.onnx", threads=0):
        options = ort.SessionOptions()
        options.intra_op_num_threads = int(threads)   # 0 lets onnxruntime use every core
        self.session = ort.InferenceSession(str(Path(path)), options, providers=["CPUExecutionProvider"])

    def feature_maps(self, images):
        """(n, 512, 7, 7) feature maps of n images, each a (224, 224) array with values from 0 to 255."""
        x = np.stack([np.asarray(im, dtype=np.float32) / 255.0 for im in images])[:, None]
        return self.session.run(None, {"image": x})[0]

    def features(self, images, batch_size=64, progress=True):
        """(n, 512) features of n images, computed in batches.

        Args:
            images: an iterable of (224, 224) arrays, for example ExerciseData.images() or a generator that changes each image first.
            batch_size: images per batch.
            progress: print the number of finished images.
        """
        out, batch, done = [], [], 0
        for im in images:
            batch.append(im)
            if len(batch) == batch_size:
                out.append(self.feature_maps(batch).mean(axis=(2, 3)))
                done += len(batch)
                batch = []
                if progress:
                    print("\r{:,} images".format(done), end="", flush=True)
        if batch:
            out.append(self.feature_maps(batch).mean(axis=(2, 3)))
            done += len(batch)
        if progress:
            print("\r{:,} images".format(done))
        return np.concatenate(out).astype(np.float32)
