"""dlmd_e2/metrics.py

DLMD exercise 2, Deep Learning for Medical Diagnostics, RWTH Aachen University, Winter Semester 2026/27.
"""

import numpy as np


def auroc(y_true, score):
    """Area under the ROC curve, computed from ranks. Tied scores get their average rank.

    Args:
        y_true: (n,) array of 0 and 1.
        score:  (n,) array of scores, where a higher score means more likely positive.

    Returns:
        The AUROC as a float in [0, 1], or nan if y_true contains only one class.
    """
    y_true = np.asarray(y_true).astype(int)
    score = np.asarray(score, dtype=float)
    order = np.argsort(score, kind="mergesort")
    ranks = np.empty(len(score), dtype=float)
    ranks[order] = np.arange(1, len(score) + 1)

    s = score[order]
    i = 0
    while i < len(s):
        j = i
        while j + 1 < len(s) and s[j + 1] == s[i]:
            j += 1
        if j > i:
            ranks[order[i:j + 1]] = (i + 1 + j + 1) / 2.0
        i = j + 1

    n1 = float(y_true.sum())
    n0 = float(len(y_true) - n1)
    if n1 == 0 or n0 == 0:
        return float("nan")
    return float((ranks[y_true == 1].sum() - n1 * (n1 + 1) / 2.0) / (n1 * n0))


def auprc(y_true, score):
    """Average precision: the mean of the precision at the rank of every positive."""
    y_true = np.asarray(y_true).astype(int)
    order = np.argsort(-np.asarray(score, dtype=float), kind="mergesort")
    y = y_true[order]
    tp = np.cumsum(y)
    precision = tp / np.arange(1, len(y) + 1)
    n_pos = y.sum()
    if n_pos == 0:
        return float("nan")
    return float((precision * y).sum() / n_pos)


def confusion(y_true, score, threshold):
    """Counts (tp, fp, tn, fn) when every score at or above the threshold is positive."""
    y_true = np.asarray(y_true).astype(int)
    pred = (np.asarray(score, dtype=float) >= threshold).astype(int)
    tp = int(((pred == 1) & (y_true == 1)).sum())
    fp = int(((pred == 1) & (y_true == 0)).sum())
    tn = int(((pred == 0) & (y_true == 0)).sum())
    fn = int(((pred == 0) & (y_true == 1)).sum())
    return tp, fp, tn, fn


def sensitivity_specificity(y_true, score, threshold):
    """Sensitivity and specificity at one threshold."""
    tp, fp, tn, fn = confusion(y_true, score, threshold)
    se = tp / (tp + fn) if (tp + fn) else float("nan")
    sp = tn / (tn + fp) if (tn + fp) else float("nan")
    return float(se), float(sp)


def ppv_npv(sensitivity, specificity, prevalence):
    """Positive and negative predictive value from Se, Sp, and a prevalence, by Bayes' rule."""
    se, sp, pi = float(sensitivity), float(specificity), float(prevalence)
    ppv = se * pi / (se * pi + (1 - sp) * (1 - pi))
    npv = sp * (1 - pi) / (sp * (1 - pi) + (1 - se) * pi)
    return float(ppv), float(npv)


def brier(y_true, prob):
    """Brier score: the mean squared difference between probability and label (0 is best)."""
    y_true = np.asarray(y_true, dtype=float)
    return float(np.mean((np.asarray(prob, dtype=float) - y_true) ** 2))


def calibration_bins(y_true, prob, n_bins=10):
    """Reliability diagram data, with n_bins bins of equal width on [0, 1].

    Returns:
        Four arrays of length n_bins: the bin centers, the share of positives in each bin, the mean predicted probability in each bin, and the number of images in each bin. An empty bin has nan as its share of positives and as its mean probability.
    """
    y_true = np.asarray(y_true, dtype=float)
    prob = np.asarray(prob, dtype=float)
    edges = np.linspace(0.0, 1.0, n_bins + 1)
    idx = np.clip(np.digitize(prob, edges[1:-1]), 0, n_bins - 1)
    centers = 0.5 * (edges[:-1] + edges[1:])
    obs = np.full(n_bins, np.nan)
    pred = np.full(n_bins, np.nan)
    count = np.zeros(n_bins, dtype=int)
    for b in range(n_bins):
        m = idx == b
        count[b] = int(m.sum())
        if count[b]:
            obs[b] = y_true[m].mean()
            pred[b] = prob[m].mean()
    return centers, obs, pred, count


def ece(y_true, prob, n_bins=10):
    """Expected calibration error over n_bins bins, weighted by the images in each bin."""
    _, obs, pred, count = calibration_bins(y_true, prob, n_bins)
    m = count > 0
    if not m.any():
        return float("nan")
    return float(np.sum(count[m] * np.abs(obs[m] - pred[m])) / count.sum())
