"""dlmd_e2/report.py

DLMD exercise 2, Deep Learning for Medical Diagnostics, RWTH Aachen University, Winter Semester 2026/27.
"""

import csv
from pathlib import Path


class ResultsTable:
    """Collects the numbers of your analysis and writes them to results.csv.

    Add one row per number that your report states.
    """

    COLUMNS = ["quantity", "split", "subset", "value", "sd", "ci_low", "ci_high", "note"]

    def __init__(self):
        self.rows = []

    def add(self, quantity, value, split="", subset="all", sd=None,
            ci_low=None, ci_high=None, note=""):
        self.rows.append({
            "quantity": quantity, "split": split, "subset": subset,
            "value": _fmt(value), "sd": _fmt(sd),
            "ci_low": _fmt(ci_low), "ci_high": _fmt(ci_high), "note": note,
        })
        return self

    def add_bootstrap(self, quantity, stats, split="", subset="all", note=""):
        """Add a (mean, sd, low, high) tuple returned by Bootstrap.run()."""
        mean, sd, low, high = stats
        return self.add(quantity, mean, split=split, subset=subset,
                        sd=sd, ci_low=low, ci_high=high, note=note)

    def write(self, path="results.csv"):
        path = Path(path)
        with path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=self.COLUMNS)
            writer.writeheader()
            writer.writerows(self.rows)
        return path

    def __str__(self):
        if not self.rows:
            return "(no results)"
        widths = {c: max(len(c), max(len(str(r[c])) for r in self.rows))
                  for c in self.COLUMNS}
        head = "  ".join(c.ljust(widths[c]) for c in self.COLUMNS)
        body = "\n".join("  ".join(str(r[c]).ljust(widths[c]) for c in self.COLUMNS)
                         for r in self.rows)
        return head + "\n" + "-" * len(head) + "\n" + body


def _fmt(v):
    return "" if v is None else "{:.4f}".format(float(v))
