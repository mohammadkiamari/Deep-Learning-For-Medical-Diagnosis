"""dlmd_e2/cam.py

DLMD exercise 2, Deep Learning for Medical Diagnostics, RWTH Aachen University, Winter Semester 2026/27.
"""

import numpy as np
from PIL import Image


def cam(head, encoder, images):
    """Class activation maps of a LinearHead on the encoder's features.

    The map of an image is the sum of its 512 feature maps, each weighted by the head's weight for that feature, upsampled from 7 by 7 to 224 by 224. For a linear head on averaged feature maps, this map equals the Grad-CAM map. A high value marks a region that raises the predicted probability.

    Returns:
        (n, 224, 224) array, one map per image.
    """
    maps = encoder.feature_maps(images)
    small = np.tensordot(head.weights, maps, axes=([0], [1]))
    return np.stack([np.asarray(Image.fromarray(m.astype(np.float32)).resize((224, 224), Image.BILINEAR))
                     for m in small])


def save_overlay(image, cam_map, path):
    """Save an image with its class activation map drawn over it, as a PNG file."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(3, 3), dpi=100)
    ax.imshow(image, cmap="gray")
    ax.imshow(cam_map, cmap="jet", alpha=0.4)
    ax.axis("off")
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    return path
