"""dlmd_e2/model.py

DLMD exercise 2, Deep Learning for Medical Diagnostics, RWTH Aachen University, Winter Semester 2026/27.
"""

import numpy as np
from sklearn.linear_model import LogisticRegression


class LinearHead:
    """Logistic regression on the 512 image features of the encoder.

    Each feature is standardized with the mean and the standard deviation of the training rows. The Newton solver then fits the model to a tolerance of 1e-8, so every computer and every scikit-learn version gives the same model.
    """

    DEFAULT_C = 0.01   # inverse L2 regularization strength of the reference model

    def __init__(self, C=DEFAULT_C, max_iter=100, tol=1e-8):
        self.C = float(C)
        self.max_iter = int(max_iter)
        self.tol = float(tol)
        self._clf = None
        self.mean = None
        self.std = None

    def fit(self, x, y):
        x = np.asarray(x, dtype=float)
        self.mean, self.std = x.mean(axis=0), x.std(axis=0) + 1e-6
        self._clf = LogisticRegression(C=self.C, max_iter=self.max_iter, tol=self.tol,
                                       solver="newton-cholesky")
        self._clf.fit((x - self.mean) / self.std, np.asarray(y).astype(int))
        return self

    def predict_proba(self, x):
        """Predicted probability of pleural effusion, one value per row of x."""
        if self._clf is None:
            raise RuntimeError("call fit() before predict_proba()")
        return self._clf.predict_proba((np.asarray(x, dtype=float) - self.mean) / self.std)[:, 1]

    def fit_predict_split(self, features, y, split, train_value="train", test_value="test"):
        """Train on the rows marked train_value and predict the rows marked test_value.

        Args:
            features: (n, 512) feature matrix.
            y: (n,) labels.
            split: (n,) array that assigns every row to a side, for example ExerciseData.split.

        Returns:
            (y_test, p_test, test_mask): the labels and the predicted probabilities of the predicted rows, and a boolean mask that marks those rows.
        """
        split = np.asarray(split)
        train, test = split == train_value, split == test_value
        if train.sum() == 0 or test.sum() == 0:
            raise ValueError("one side of the split is empty")
        self.fit(features[train], y[train])
        return y[test], self.predict_proba(features[test]), test

    @property
    def weights(self):
        """The 512 weights of the fitted model for the unstandardized features, one per feature."""
        if self._clf is None:
            raise RuntimeError("call fit() before reading the weights")
        return self._clf.coef_[0] / self.std

    def save(self, path="model.npz"):
        """Save the fitted model, so that it can be loaded again with LinearHead.load()."""
        if self._clf is None:
            raise RuntimeError("call fit() before save()")
        np.savez(path, coef=self._clf.coef_, intercept=self._clf.intercept_, C=self.C,
                 mean=self.mean, std=self.std)
        return path

    @classmethod
    def load(cls, path="model.npz"):
        """Load a model saved with save()."""
        with np.load(path) as f:
            head = cls(C=float(f["C"]))
            head._clf = LogisticRegression(C=head.C)
            head._clf.coef_ = f["coef"]
            head._clf.intercept_ = f["intercept"]
            head._clf.classes_ = np.array([0, 1])
            head.mean, head.std = f["mean"], f["std"]
        return head
