"""dlmd_e2/data.py

DLMD exercise 2, Deep Learning for Medical Diagnostics, RWTH Aachen University, Winter Semester 2026/27.
"""

from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image


class ExerciseData:
    """The image table, the images, and the shipped features of the exercise, with their rows aligned.

    Row i of `features` and row i of `index` describe the same image.
    """

    def __init__(self, root="data"):
        self.root = Path(root)
        self.index = self._load_index()
        self.features = self._load_features()

    def _load_index(self):
        try:
            return pd.read_csv(self.root / "index.csv", low_memory=False)
        except UnicodeDecodeError:
            return pd.read_csv(self.root / "index.csv", low_memory=False, encoding="latin-1")

    def _load_features(self):
        """The features of the original images, sorted into the row order of index.csv."""
        with np.load(self.root / "features.npz", allow_pickle=False) as f:
            x, ids = f["X"].astype(np.float32), f["image_id"].astype(str)
        if set(ids) != set(self.index.image_id):
            raise ValueError("features.npz and index.csv do not contain the same images")
        row = {image_id: i for i, image_id in enumerate(ids)}
        return x[[row[i] for i in self.index.image_id]]

    @property
    def y(self):
        """The label of each image: 1 for pleural effusion and 0 otherwise."""
        return self.index.label.values.astype(int)

    @property
    def site(self):
        """The hospital of each image: "A" or "B"."""
        return self.index.site.values.astype(str)

    @property
    def split(self):
        """The split of each image: "train" or "test" at hospital A, and "external" at hospital B."""
        return self.index.split.values.astype(str)

    @property
    def patient_id(self):
        """The patient id of each image."""
        return self.index.patient_id.values

    def image(self, i):
        """The image of row i as a (224, 224) array of uint8."""
        return np.asarray(Image.open(self.root / "images" / (self.index.image_id.iloc[i] + ".jpg")).convert("L"))

    def images(self, rows=None):
        """The images of the given rows, or of all rows, one after the other."""
        for i in (range(len(self.index)) if rows is None else rows):
            yield self.image(i)

    def describe(self):
        """A short text summary of the data."""
        lines = ["images {:,}, patients {:,}".format(len(self.index), self.index.patient_id.nunique())]
        for site, split in (("A", "train"), ("A", "test"), ("B", "external")):
            part = self.index[(self.index.site == site) & (self.index.split == split)]
            lines.append("hospital {}, {}: {:,} images, share with effusion {:.3f}".format(
                site, split, len(part), part.label.mean()))
        lines.append("columns: " + ", ".join(self.index.columns))
        return "\n".join(lines)
